package parqueaderoapp;

import javax.swing.*;
import java.awt.*;
import java.util.Map;

public class TarifaDialog extends JDialog {
	private static final long serialVersionUID = 1L;

    public TarifaDialog(JFrame owner, Parqueadero parqueadero) {
        super(owner, "Configurar tarifas", true);
        setLayout(new BorderLayout(5,5));

        Map<String,Integer> tarifas = parqueadero.getTarifa().getTodas();

        JPanel campos = new JPanel(new GridLayout(tarifas.size(), 2, 5, 5));
        java.util.Map<String, JTextField> fields = new java.util.HashMap<>();

        for (String tipo : tarifas.keySet()) {
            campos.add(new JLabel(tipo + ":"));
            JTextField tf = new JTextField(String.valueOf(tarifas.get(tipo)));
            fields.put(tipo, tf);
            campos.add(tf);
        }

        add(campos, BorderLayout.CENTER);

        JButton btnGuardar = new JButton("Guardar");
        btnGuardar.addActionListener(e -> {
            try {
                for (Map.Entry<String,JTextField> entry : fields.entrySet()) {
                    String tipo = entry.getKey();
                    int valor = Integer.parseInt(entry.getValue().getText().trim());
                    parqueadero.actualizarTarifa(tipo, valor);
                }
                dispose();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Valores inválidos", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
        add(btnGuardar, BorderLayout.SOUTH);

        pack();
        setLocationRelativeTo(owner);
    }
}