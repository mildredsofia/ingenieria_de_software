package parqueaderoapp;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class Tarifa implements Serializable {
	private static final long serialVersionUID = 1L;
    private final Map<String, Integer> tarifas = new HashMap<>();

    public Tarifa() {
        tarifas.put("Carro", 2000);
        tarifas.put("Moto", 1000);
        tarifas.put("Bus", 5000);
        tarifas.put("Bicicleta", 500);
    }

    public int getTarifa(String tipo) {
        return tarifas.getOrDefault(tipo, 0);
    }

    public void setTarifa(String tipo, int valor) {
        tarifas.put(tipo, valor);
    }

    public Map<String, Integer> getTodas() {
        return new HashMap<>(tarifas);
    }
}