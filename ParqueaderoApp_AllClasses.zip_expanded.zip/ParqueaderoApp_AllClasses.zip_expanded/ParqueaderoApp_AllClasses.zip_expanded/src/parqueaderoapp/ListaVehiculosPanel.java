package parqueaderoapp;

import javax.swing.*;
import java.awt.*;
import java.time.LocalDateTime;
import java.util.*;
import java.util.List;
import java.util.stream.Collectors;

public class ListaVehiculosPanel extends JPanel {
	private static final long serialVersionUID = 1L;
    private final Parqueadero parqueadero;
    private final JPanel contenedor = new JPanel();
    private final Map<String, ImageIcon> iconos = new HashMap<>();
    private String filtro = "";

    private int pagina = 0;
    private static final int PAGE_SIZE = 3;
    private final JButton btnPrev = new JButton("<< Anterior");
    private final JButton btnNext = new JButton("Siguiente >>");
    private final JLabel lblInfo = new JLabel(" ");

    public ListaVehiculosPanel(Parqueadero parqueadero) {
        this.parqueadero = parqueadero;
        setLayout(new BorderLayout(5,5));

        JPanel top = new JPanel(new BorderLayout(5,5));
        JTextField txtBuscar = new JTextField();
        JButton btnBuscar = new JButton("Buscar");
        btnBuscar.addActionListener(e -> {
            filtro = txtBuscar.getText().trim().toUpperCase();
            pagina = 0;
            actualizarLista();
        });
        top.add(txtBuscar, BorderLayout.CENTER);
        top.add(btnBuscar, BorderLayout.EAST);
        add(top, BorderLayout.NORTH);

        contenedor.setLayout(new BoxLayout(contenedor, BoxLayout.Y_AXIS));
        JScrollPane scroll = new JScrollPane(contenedor);
        add(scroll, BorderLayout.CENTER);

        JPanel pagination = new JPanel(new FlowLayout(FlowLayout.CENTER));
        btnPrev.addActionListener(e -> { pagina--; actualizarLista(); });
        btnNext.addActionListener(e -> { pagina++; actualizarLista(); });
        pagination.add(btnPrev);
        pagination.add(lblInfo);
        pagination.add(btnNext);
        add(pagination, BorderLayout.SOUTH);

        iconos.put("Carro",     new ImageIcon(getClass().getResource("/recursos/carro.png")));
        iconos.put("Moto",      new ImageIcon(getClass().getResource("/recursos/moto.png")));
        iconos.put("Bus",       new ImageIcon(getClass().getResource("/recursos/bus.png")));
        iconos.put("Bicicleta", new ImageIcon(getClass().getResource("/recursos/bicicleta.png")));

        actualizarLista();
    }

    public void actualizarLista() {
        contenedor.removeAll();

        List<Vehiculo> listaFiltrada = parqueadero.getVehiculosActuales().stream()
            .filter(v -> filtro.isEmpty() || v.getPlaca().toUpperCase().contains(filtro))
            .collect(Collectors.toList());

        int totalPaginas = (int) Math.ceil(listaFiltrada.size() / (double) PAGE_SIZE);
        if (pagina >= totalPaginas) pagina = Math.max(0, totalPaginas - 1);

        int start = pagina * PAGE_SIZE;
        int end = Math.min(start + PAGE_SIZE, listaFiltrada.size());

        for (int i = start; i < end; i++) {
            Vehiculo v = listaFiltrada.get(i);
            JPanel item = crearItem(v);
            contenedor.add(item);
        }

        contenedor.revalidate();
        contenedor.repaint();

        lblInfo.setText("Página " + (pagina+1) + " de " + (totalPaginas==0?1:totalPaginas));
        btnPrev.setEnabled(pagina > 0);
        btnNext.setEnabled(pagina < totalPaginas - 1);
    }

    private JPanel crearItem(Vehiculo v) {
        JPanel item = new JPanel(new FlowLayout(FlowLayout.LEFT));
        item.setBorder(BorderFactory.createMatteBorder(
                0, 0, 1, 0, Color.LIGHT_GRAY));

        item.add(new JLabel(iconos.get(v.getTipo())));
        item.add(new JLabel(v.getTipo() + " - " + v.getPlaca() + " - " + v.getUsuario()));

        JButton btnSalida = new JButton("Salida");
        btnSalida.addActionListener(e -> emitirTicket(v.getPlaca()));
        item.add(btnSalida);

        return item;
    }

    private void emitirTicket(String placa) {
        Ticket t = parqueadero.generarTicketYSalir(placa, LocalDateTime.now());
        if (t != null) {
            JOptionPane.showMessageDialog(this, t.toString(),
                    "Ticket de pago", JOptionPane.INFORMATION_MESSAGE);
            actualizarLista();
        }
    }
}