package parqueaderoapp;

import javax.swing.*;
import java.awt.*;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

public class RegistroVehiculoPanel extends JPanel {
	private static final long serialVersionUID = 1L;

    private final JTextField txtPlaca;
    private final JTextField txtNombre;
    private final JTextField txtDocumento;
    private final JComboBox<String> comboTipo;
    private final JLabel lblIcono;
    private final Parqueadero parqueadero;
    private final ListaVehiculosPanel listaPanel;
    private final Map<String, ImageIcon> iconos = new HashMap<>();

    public RegistroVehiculoPanel(Parqueadero parqueadero,
                                 ListaVehiculosPanel listaPanel) {

        this.parqueadero = parqueadero;
        this.listaPanel  = listaPanel;

        setLayout(new BorderLayout(5,5));

        JPanel form = new JPanel(new GridLayout(4,2,5,5));

        form.add(new JLabel("Placa:"));
        txtPlaca = new JTextField();
        form.add(txtPlaca);

        form.add(new JLabel("Nombre:"));
        txtNombre = new JTextField();
        form.add(txtNombre);

        form.add(new JLabel("Documento:"));
        txtDocumento = new JTextField();
        form.add(txtDocumento);

        form.add(new JLabel("Tipo:"));
        comboTipo = new JComboBox<>(new String[]{
                "Carro","Moto","Bus","Bicicleta"});
        form.add(comboTipo);
        add(form, BorderLayout.NORTH);

        cargarIconos();
        lblIcono = new JLabel(iconos.get("Carro"));
        lblIcono.setHorizontalAlignment(SwingConstants.CENTER);
        add(lblIcono, BorderLayout.CENTER);

        comboTipo.addActionListener(e ->
                lblIcono.setIcon(iconos.get(comboTipo.getSelectedItem())));

        JButton btnRegistrar = new JButton("Registrar vehículo");
        btnRegistrar.addActionListener(e -> registrarVehiculo());
        add(btnRegistrar, BorderLayout.SOUTH);
    }

    private void cargarIconos() {
        iconos.put("Carro",      cargar("/recursos/carro.png"));
        iconos.put("Moto",       cargar("/recursos/moto.png"));
        iconos.put("Bus",        cargar("/recursos/bus.png"));
        iconos.put("Bicicleta",  cargar("/recursos/bicicleta.png"));
    }

    private ImageIcon cargar(String ruta) {
        java.net.URL url = getClass().getResource(ruta);
        return url == null ? null : new ImageIcon(url);
    }

    private void registrarVehiculo() {
        String placa = txtPlaca.getText().trim().toUpperCase();
        String nombre = txtNombre.getText().trim();
        String documento = txtDocumento.getText().trim();

        if (placa.isEmpty() || nombre.isEmpty() || documento.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Todos los campos son obligatorios.",
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (parqueadero.existeVehiculo(placa)) {
            JOptionPane.showMessageDialog(this,
                    "Ya existe un vehículo con esa placa.",
                    "Duplicado", JOptionPane.WARNING_MESSAGE);
            return;
        }

        Usuario usuario = new Usuario(nombre, documento);
        String tipo = (String) comboTipo.getSelectedItem();
        Vehiculo v = new Vehiculo(placa, tipo, usuario, LocalDateTime.now());
        parqueadero.ingresarVehiculo(v);
        listaPanel.actualizarLista();

        txtPlaca.setText("");
        txtNombre.setText("");
        txtDocumento.setText("");
    }
}