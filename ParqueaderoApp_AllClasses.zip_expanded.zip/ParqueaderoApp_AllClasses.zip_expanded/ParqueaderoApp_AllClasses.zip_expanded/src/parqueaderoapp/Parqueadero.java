package parqueaderoapp;

import java.io.*;
import java.util.*;
import java.time.LocalDateTime;

@SuppressWarnings("unchecked")
public class Parqueadero implements Serializable {
	private static final long serialVersionUID = 1L;
    private int capacidad;
    private final List<Vehiculo> vehiculosActuales;
    private Tarifa tarifa;

    private static final String ARCHIVO_VEHICULOS = "archivos/vehiculos.dat";
    private static final String ARCHIVO_TARIFA    = "archivos/tarifa.dat";

    public Parqueadero() { this(100); }

    public Parqueadero(int capacidad) {
        this.capacidad = capacidad;
        this.vehiculosActuales = cargarVehiculos();
        this.tarifa = cargarTarifa();
    }

    public List<Vehiculo> getVehiculosActuales() {
        return Collections.unmodifiableList(vehiculosActuales);
    }

    public boolean existeVehiculo(String placa) {
        return vehiculosActuales.stream()
                .anyMatch(v -> v.getPlaca().equalsIgnoreCase(placa));
    }

    public void ingresarVehiculo(Vehiculo v) {
        if (vehiculosActuales.size() >= capacidad)
            throw new IllegalStateException("No hay cupos disponibles.");
        vehiculosActuales.add(v);
        guardarVehiculos();
    }

    public Ticket generarTicketYSalir(String placa, LocalDateTime salida) {
        Iterator<Vehiculo> it = vehiculosActuales.iterator();
        while (it.hasNext()) {
            Vehiculo v = it.next();
            if (v.getPlaca().equalsIgnoreCase(placa)) {
                it.remove();
                guardarVehiculos();
                int tarifaHora = tarifa.getTarifa(v.getTipo());
                return new Ticket(v, salida, tarifaHora);
            }
        }
        return null;
    }

    /* --- Tarifas --- */
    public Tarifa getTarifa() { return tarifa; }

    public void actualizarTarifa(String tipo, int valor) {
        tarifa.setTarifa(tipo, valor);
        guardarTarifa();
    }

    /* --- Persistencia --- */
    private void guardarVehiculos() {
        try (ObjectOutputStream out = new ObjectOutputStream(
                new FileOutputStream(ARCHIVO_VEHICULOS))) {
            out.writeObject(vehiculosActuales);
        } catch (IOException e) { e.printStackTrace(); }
    }

    private List<Vehiculo> cargarVehiculos() {
        File f = new File(ARCHIVO_VEHICULOS);
        if (!f.exists()) return new ArrayList<>();
        try (ObjectInputStream in = new ObjectInputStream(
                new FileInputStream(f))) {
            return (List<Vehiculo>) in.readObject();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }

    private void guardarTarifa() {
        try (ObjectOutputStream out = new ObjectOutputStream(
                new FileOutputStream(ARCHIVO_TARIFA))) {
            out.writeObject(tarifa);
        } catch (IOException e) { e.printStackTrace(); }
    }

    private Tarifa cargarTarifa() {
        File f = new File(ARCHIVO_TARIFA);
        if (!f.exists()) return new Tarifa();
        try (ObjectInputStream in = new ObjectInputStream(
                new FileInputStream(f))) {
            return (Tarifa) in.readObject();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
            return new Tarifa();
        }
    }
}