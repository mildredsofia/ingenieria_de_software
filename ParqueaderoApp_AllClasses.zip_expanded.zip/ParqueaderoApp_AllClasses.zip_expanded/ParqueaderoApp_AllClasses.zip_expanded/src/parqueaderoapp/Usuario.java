package parqueaderoapp;

import java.io.Serializable;

public class Usuario implements Serializable {
	private static final long serialVersionUID = 1L;
    private final String nombre;
    private final String documento;

    public Usuario(String nombre, String documento) {
        this.nombre = nombre;
        this.documento = documento;
    }

    public String getNombre()   { return nombre; }
    public String getDocumento(){ return documento; }

    @Override
    public String toString() {
        return nombre + " (" + documento + ")";
    }
}