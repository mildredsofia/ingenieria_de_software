package parqueaderoapp;

import java.io.Serializable;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Ticket implements Serializable {
	private static final long serialVersionUID = 1L;
    private final String placa;
    private final String tipo;
    private final LocalDateTime entrada;
    private final LocalDateTime salida;
    private final int tarifaHora;
    private final long horas;
    private final long totalPagar;
    private final Usuario usuario;

    public Ticket(Vehiculo v, LocalDateTime salida, int tarifaHora) {
        this.placa = v.getPlaca();
        this.tipo = v.getTipo();
        this.entrada = v.getHoraEntrada();
        this.salida = salida;
        this.tarifaHora = tarifaHora;
        this.usuario = v.getUsuario();

        long diff = Duration.between(entrada, salida).toMinutes();
        this.horas = Math.max(1, (diff + 59) / 60);
        this.totalPagar = this.horas * tarifaHora;
    }

    public long getTotalPagar() { return totalPagar; }

    @Override
    public String toString() {
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        return "TICKET DE PAGO\n" +
               "Cliente: " + usuario + "\n" +
               "Placa: " + placa + "\n" +
               "Tipo: " + tipo + "\n" +
               "Entrada: " + entrada.format(fmt) + "\n" +
               "Salida: " + salida.format(fmt) + "\n" +
               "Horas: " + horas + "\n" +
               "Tarifa/hora: $" + tarifaHora + "\n" +
               "TOTAL A PAGAR: $" + totalPagar;
    }
}