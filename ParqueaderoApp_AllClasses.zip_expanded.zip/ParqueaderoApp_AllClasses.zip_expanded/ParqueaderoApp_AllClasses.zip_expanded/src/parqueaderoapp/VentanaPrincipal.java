package parqueaderoapp;

import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class VentanaPrincipal extends JFrame {
	private static final long serialVersionUID = 1L;
    private static final int WIDTH = 900;
    private static final int HEIGHT = 550;

    public VentanaPrincipal() {
        setTitle("Parqueadero App");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(WIDTH, HEIGHT);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(5,5));

        JLabel banner;
        java.net.URL urlBanner = getClass().getResource("/recursos/banner.png");
        if (urlBanner != null) {
            banner = new JLabel(new ImageIcon(urlBanner));
        } else {
            banner = new JLabel("Banner Parqueadero (900x120)", SwingConstants.CENTER);
        }
        banner.setPreferredSize(new Dimension(WIDTH, 120));
        add(banner, BorderLayout.NORTH);

        // ✅ Cargar el estado desde archivo
        Parqueadero parqueadero = Persistencia.cargarEstado();

        ListaVehiculosPanel listaPanel = new ListaVehiculosPanel(parqueadero);
        RegistroVehiculoPanel registroPanel = new RegistroVehiculoPanel(parqueadero, listaPanel);

        add(registroPanel, BorderLayout.WEST);
        add(listaPanel, BorderLayout.CENTER);

        JButton btnTarifas = new JButton("Configurar tarifas");
        btnTarifas.addActionListener(e ->
                new TarifaDialog(this, parqueadero).setVisible(true));

        JPanel south = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        south.add(btnTarifas);
        add(south, BorderLayout.SOUTH);

        // ✅ Guardar estado al cerrar la ventana
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                Persistencia.guardarEstado(parqueadero);
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new VentanaPrincipal().setVisible(true));
    }
}
