package parqueaderoapp;

import java.io.Serializable;
import java.time.LocalDateTime;

public class Vehiculo implements Serializable {
	private static final long serialVersionUID = 1L;
    private String placa;
    private String tipo;
    private LocalDateTime horaEntrada;
    private LocalDateTime horaSalida;
    private Usuario usuario;

    public Vehiculo(String placa, String tipo, Usuario usuario) {
        this(placa, tipo, usuario, LocalDateTime.now());
    }

    public Vehiculo(String placa, String tipo, Usuario usuario, LocalDateTime horaEntrada) {
        this.placa = placa;
        this.tipo  = tipo;
        this.usuario = usuario;
        this.horaEntrada = horaEntrada;
    }

    public String getPlaca()        { return placa; }
    public String getTipo()         { return tipo;  }
    public LocalDateTime getHoraEntrada() { return horaEntrada; }
    public LocalDateTime getHoraSalida()  { return horaSalida;  }
    public Usuario getUsuario()     { return usuario; }

    public void setHoraSalida(LocalDateTime horaSalida) {
        this.horaSalida = horaSalida;
    }

    @Override
    public String toString() {
        return tipo + " - " + placa + " / " + usuario;
    }
}