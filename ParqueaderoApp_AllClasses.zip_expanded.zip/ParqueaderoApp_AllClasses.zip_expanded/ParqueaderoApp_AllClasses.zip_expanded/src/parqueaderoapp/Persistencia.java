package parqueaderoapp;

import java.io.*;

public class Persistencia {

    private static final String ARCHIVO_DATOS = "parqueadero.dat";

    public static void guardarEstado(Parqueadero parqueadero) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(ARCHIVO_DATOS))) {
            oos.writeObject(parqueadero);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static Parqueadero cargarEstado() {
        File archivo = new File(ARCHIVO_DATOS);
        if (!archivo.exists()) return new Parqueadero(); // nuevo si no existe

        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(ARCHIVO_DATOS))) {
            return (Parqueadero) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
            return new Parqueadero(); // nuevo si hay error
        }
    }
}
